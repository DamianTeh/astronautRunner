package AstronautRunnerPackage

import AstronautRunnerPackage.model.Difficulty.Normal
import AstronautRunnerPackage.model.Sound.backgroundMusic
import AstronautRunnerPackage.model.{Difficulty, Player, Sound}
import AstronautRunnerPackage.util.Database
import scalafx.Includes._
import scalafx.application.JFXApp
import scalafx.application.JFXApp.PrimaryStage
import scalafx.scene.Scene
import scalafx.scene.image.Image
import scalafx.scene.text.Font
import scalafxml.core.{FXMLLoader, NoDependencyResolver}

object MainApp extends JFXApp {

  Database.setupDB()

  var playerName: String = "Player"
  var gameResult: Player = Player.empty
  var difficultyLevel: Difficulty = Normal

  // Load Font
  Font.loadFont(getClass.getResourceAsStream("/assets/font/ARCADE_N.TTF"), 12)

  // Show Game Scene
  def startGame(difficulty: Difficulty): Unit = {
    difficultyLevel = difficulty
    val resource = getClass.getResource("/GameScene.fxml")
    if (resource == null) {
      throw new IllegalArgumentException("GameScene.fxml not found")
    }
    val loader = new FXMLLoader(resource, NoDependencyResolver)
    loader.load()
    val AP = loader.getRoot[javafx.scene.layout.AnchorPane]
    BP.center = AP
  }

  // Show the difficulty level page
  def showDifficultyLevel(): Unit = {
    val resource = getClass.getResource("/DifficultyLevel.fxml")
    if (resource == null) {
      throw new IllegalArgumentException("DifficultyLevel.fxml not found")
    }
    val loader = new FXMLLoader(resource, NoDependencyResolver)
    loader.load()
    val AP = loader.getRoot[javafx.scene.layout.AnchorPane]
    BP.center = AP
  }

  // Show the main menu page
  def showMainMenu(): Unit = {
    val resource = getClass.getResource("/MainMenu.fxml")
    if (resource == null) {
      throw new IllegalArgumentException("MainMenu.fxml not found")
    }
    val loader = new FXMLLoader(resource, NoDependencyResolver)
    loader.load()
    val AP = loader.getRoot[javafx.scene.layout.AnchorPane]
    BP.center = AP
  }

  //Show game over page
  def showGameOver(): Unit = {
    val resource = getClass.getResource("/GameOver.fxml")
    if (resource == null) {
      throw new IllegalArgumentException("GameOver.fxml not found")
    }
    val loader = new FXMLLoader(resource, NoDependencyResolver)
    loader.load()
    val AP = loader.getRoot[javafx.scene.layout.AnchorPane]
    BP.center = AP
  }

  def showLeaderboard():  Unit = {
    val resource = getClass.getResource("/Leaderboard.fxml")
    if (resource == null) {
      throw new IllegalArgumentException("Leaderboard.fxml not found")
    }
    val loader = new FXMLLoader(resource, NoDependencyResolver)
    loader.load()
    val AP = loader.getRoot[javafx.scene.layout.AnchorPane]
    BP.center = AP
  }

  //show rules page
  def showRules(): Unit = {
    val resource = getClass.getResource("/Rules.fxml")
    if (resource == null) {
      throw new IllegalArgumentException("Rules.fxml not found")
    }
    val loader = new FXMLLoader(resource, NoDependencyResolver)
    loader.load()
    val AP = loader.getRoot[javafx.scene.layout.AnchorPane]
    BP.center = AP
  }

  //Toggle Music
  def toggleMusic(): Boolean = {
    if (Sound.backgroundMusic.isPlaying) {
      Sound.backgroundMusic.stop()
      false
    } else {
      Sound.backgroundMusic.play()
      true
    }
  }

  //Button click sound
  def clickSound(): Unit = {
    Sound.buttonSoundEffect.stop()
    Sound.buttonSoundEffect.play()
  }

  val resource = getClass.getResource("/RootLayout.fxml")
  if (resource == null) {
    throw new IllegalArgumentException("RootLayout.fxml not found")
  }
  val loader = new FXMLLoader(resource, NoDependencyResolver)
  loader.load[javafx.scene.layout.BorderPane]
  val BP: scalafx.scene.layout.BorderPane = loader.getRoot[javafx.scene.layout.BorderPane]

  stage = new PrimaryStage {
    title = "Astronaut Runner"
    icons += new Image(getClass.getResourceAsStream("/assets/images/astronautRunnerIcon.jpg"))
    minWidth = 1280
    minHeight = 720
    scene = new Scene() {
      root = BP
    }
  }

  // Running the main
  showMainMenu()
  backgroundMusic.play()
}
