package AstronautRunnerPackage.model

import scalafx.scene.media.{Media, MediaPlayer}

class Sound(private val soundFilePath: String, private val volume: Double, private val autoPlay: Boolean, private val cycleCount: Int) {

  private val media: Media = new Media(getClass.getResource(soundFilePath).toString)
  private var mediaPlayer: MediaPlayer = _

  // Initialize the MediaPlayer
  private def initializePlayer(): Unit = {
    mediaPlayer = new MediaPlayer(media) {
      this.volume = Sound.this.volume
      this.autoPlay = Sound.this.autoPlay
      this.cycleCount = Sound.this.cycleCount
    }
  }

  // Play the sound
  def play(): Unit = {
    if (mediaPlayer != null) {
      mediaPlayer.stop()
    }
    initializePlayer()
    mediaPlayer.play()
  }

  // Stop the sound
  def stop(): Unit = {
    if (mediaPlayer != null) {
      mediaPlayer.stop()
    }
  }

  // Check if the sound is currently playing
  def isPlaying: Boolean = {
    val isPlaying = mediaPlayer.status().toString
    if (isPlaying == "PLAYING") {
      true
    }
    else
      false
  }

}

  object Sound {
    val buttonSoundEffect = new Sound("/assets/sound/buttonSoundEffect.mp3", 1.0, false, 1)
    val backgroundMusic = new Sound("/assets/sound/bgmMusic.mp3", 0.2, false, 1000)
    val jetpackSound = new Sound("/assets/sound/jetpackSoundEffect.mp3", 0.2, false, 1)
    val coinSound = new Sound("/assets/sound/coinSoundEffect.mp3", 1.0, false, 1)
    val gameOverSound = new Sound("/assets/sound/gameOverSound.mp3", 1.0, false, 1)
  }
