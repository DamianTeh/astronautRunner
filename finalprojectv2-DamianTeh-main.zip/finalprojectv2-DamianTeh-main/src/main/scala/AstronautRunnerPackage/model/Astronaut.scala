package AstronautRunnerPackage.model

import scalafx.scene.image.{Image, ImageView}
import scalafx.scene.shape.Ellipse

class Astronaut(initialX: Double, initialY: Double) {

  //creating astronaut imageview and hitbox
  val imageView: ImageView = new ImageView(Astronaut.withoutFlamesImage) {
    fitWidth = 300
    fitHeight = 300
    preserveRatio = true
    layoutX = initialX
    layoutY = initialY
  }

  val hitbox: Ellipse = new Ellipse() {
    centerX = imageView.layoutX.value + imageView.fitWidth.value / 1.9
    centerY = imageView.layoutY.value + imageView.fitHeight.value / 4
    radiusX = imageView.fitWidth.value / 15
    radiusY = imageView.fitHeight.value / 10
    visible = false
  }

  //moving astronaut vertically but remain in the bound
  def moveVertically(amount: Double, gameAreaHeight: Double): Unit = {
    if (imageView.layoutY.value + amount >= 0 && imageView.layoutY.value + amount + imageView.fitHeight.value/2 <= gameAreaHeight) {
      imageView.layoutY.value += amount
      updateHitbox()
      if (amount < 0) {
        imageView.image = Astronaut.withFlamesImage
      } else if (amount > 0) {
        imageView.image = Astronaut.withoutFlamesImage
      }
    }
  }

  //Updating the hitbox to follow the astronaut
  def updateHitbox(): Unit = {
    hitbox.centerX = imageView.layoutX.value + imageView.fitWidth.value / 1.9
    hitbox.centerY = imageView.layoutY.value + imageView.fitHeight.value / 4
  }

  //Gravity that applies every second
  def applyGravity(gameAreaHeight: Double): Unit = {

    if (imageView.layoutY.value + imageView.fitHeight.value/2 <= gameAreaHeight) {
      imageView.layoutY = imageView.layoutY.value + 0.2
      updateHitbox()
    } else {
      imageView.layoutY = gameAreaHeight - imageView.fitHeight.value
      updateHitbox()
    }
  }
}

//Companion Object
object Astronaut {
  val withFlamesImage: Image = new Image(getClass.getResource("/assets/images/astronautWithFlames.png").toString)
  val withoutFlamesImage: Image = new Image(getClass.getResource("/assets/images/astronautWithoutFlames.png").toString)
}

