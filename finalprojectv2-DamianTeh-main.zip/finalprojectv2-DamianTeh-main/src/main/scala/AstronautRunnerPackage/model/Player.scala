package AstronautRunnerPackage.model

import AstronautRunnerPackage.util.Database
import scalafx.beans.property.{IntegerProperty, StringProperty}
import scalikejdbc._
import scala.util.Try

class Player(val _name: String, val _score: Int, val _coinScore: Int, val _difficultyLevel: String) {

  var name: StringProperty = StringProperty(_name)
  var score: IntegerProperty = IntegerProperty(_score)
  var coinScore: IntegerProperty = IntegerProperty(_coinScore)
  var difficultyLevel: StringProperty = StringProperty(_difficultyLevel)

  def save(): Try[Int] = {
    Try(DB autoCommit { implicit session =>
      sql"""
         insert into players (
                             name,
                             score,
                             coinScore,
                             difficultyLevel
                             ) values (
                                       ${name.value},
                                       ${score.value},
                                       ${coinScore.value},
                                       ${difficultyLevel.value}
                                       )
       """.update.apply()
    })
  }

}

object Player extends Database {

  def apply(nameS: String, scoreS: Int, coinScoreS: Int, difficultyLevelS: String): Player = {
    new Player(nameS, scoreS, coinScoreS, difficultyLevelS)
  }

  val empty: Player = new Player("", 0, 0, "")

  def dropTable(): Unit = {
    DB autoCommit { implicit session =>
      sql"""
        DROP TABLE players
      """.execute.apply()
    }
  }

  def initializeTable(): Unit = {
    DB autoCommit { implicit session =>
      // Check if the table exists
      val tableExists = Try {
        sql"SELECT 1 FROM players FETCH FIRST ROW ONLY".map(_.int(1)).single.apply()
      }.isSuccess

      if (!tableExists) {
        // Create the table if it doesn't exist
        sql"""
        CREATE TABLE players (
          id INT GENERATED ALWAYS AS IDENTITY (START WITH 1, INCREMENT BY 1) PRIMARY KEY,
          name VARCHAR(64),
          score INT,
          coinScore INT,
          difficultyLevel VARCHAR(20)
        )
      """.execute.apply()
      }
    }
  }

  def getPlayers(count: Int): List[Player] = {
    DB readOnly { implicit session =>
      sql"select * from players order by score desc fetch first ${count} rows only".map(rs => {
        Player(rs.string("name"), rs.int("score"), rs.int("coinScore"), rs.string("difficultyLevel"))}).list.apply()
      }
  }

  def getPlayersByDifficulty(difficulty: String, limit: Int ): List[Player] = {
    DB readOnly { implicit session =>
      sql"""
           SELECT * FROM players
           WHERE difficultyLevel = $difficulty
           ORDER BY score DESC
           FETCH FIRST $limit ROWS ONLY
         """.map(rs => Player(rs.string("name"), rs.int("score"), rs.int("coinScore"), rs.string("difficultyLevel"))).list.apply()
    }
  }
}
