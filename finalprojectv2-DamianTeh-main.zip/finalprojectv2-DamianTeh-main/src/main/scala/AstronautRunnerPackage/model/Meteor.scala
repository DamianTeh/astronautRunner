package AstronautRunnerPackage.model
import AstronautRunnerPackage.MainApp.difficultyLevel
import scalafx.scene.image.{Image, ImageView}
import scalafx.scene.shape.Rectangle

class Meteor(initialX: Double, initialY: Double) extends GameObject {

  //creating Meteor imageview and hitbox
  val imageView: ImageView = new ImageView(Meteor.image) {
    fitWidth = 120
    fitHeight = 240
    preserveRatio = true
    layoutX = initialX
    layoutY = initialY
  }

  val hitbox: Rectangle = new Rectangle() {
    width = imageView.fitWidth.value / 2
    height = imageView.fitHeight.value / 8
    layoutX = imageView.layoutX.value + imageView.fitWidth.value / 4
    layoutY = imageView.layoutY.value + imageView.fitHeight.value / 5
    visible = false
  }

  //moving coin left to right
  def move(): Unit = {
    imageView.layoutX = imageView.layoutX.value - Meteor.speed
    hitbox.layoutX = imageView.layoutX.value + imageView.fitWidth.value / 4
    hitbox.layoutY = imageView.layoutY.value + imageView.fitHeight.value / 15
  }

  //boolean to check if coin is offscreen
  def isOffScreen: Boolean = imageView.layoutX.value < -imageView.fitWidth.value

  //boolean to check if astronaut has collide with coin
  def checkCollision(player: Astronaut): Boolean = hitbox.boundsInParent().intersects(player.hitbox.boundsInParent())
}

//Companion Object
object Meteor {
  val image: Image = new Image(getClass.getResource("/assets/images/meteor.png").toString)
  var speed: Double = difficultyLevel.speed // This can be adjusted based on difficulty
  var spawnRate: Double = difficultyLevel.meteorSpawnRate // This can be adjusted based on difficulty
  var maxNumber: Int = difficultyLevel.numberOfMeteors // This can be adjusted based on difficulty

  // Method to update properties based on the current difficulty level
  def updateProperties(): Unit = {
    speed = difficultyLevel.speed
    spawnRate = difficultyLevel.meteorSpawnRate
    maxNumber = difficultyLevel.numberOfMeteors
  }
}