package AstronautRunnerPackage.model

class Difficulty(val name: String, val meteorSpawnRate: Double, val numberOfMeteors: Int, val speed: Int){}

object Difficulty{
  val Easy = new Difficulty("Easy", 0.005, 8, 3)
  val Normal = new Difficulty("Normal", 0.01, 10, 5)
  val Hard = new Difficulty("Hard", 0.02, 12, 7)
}