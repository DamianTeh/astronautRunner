package AstronautRunnerPackage.model

//Base functions that every gameobject has
trait GameObject {
  def move(): Unit
  def isOffScreen: Boolean
  def checkCollision(player: Astronaut): Boolean
}