package AstronautRunnerPackage.util

import scalafx.collections.ObservableBuffer

object CommonUtil {

  def listToObservableBuffer[A](list: List[A]): ObservableBuffer[A] = {
    val observableBuffer = new ObservableBuffer[A]()
    list.foreach(item => observableBuffer.add(item))
    observableBuffer
  }
}