package AstronautRunnerPackage.util

import scalikejdbc._
import AstronautRunnerPackage.model.Player

trait Database {
  var derbyDriverClassName: String = "org.apache.derby.jdbc.EmbeddedDriver"

  val dbURL: String = "jdbc:derby:AstronautRunnerDB;create=true;"

  Class.forName(derbyDriverClassName)

  ConnectionPool.singleton(dbURL, "AstronautRunner", "AstronautRunner")

  implicit val session: DBSession = AutoSession
}

object Database extends Database {
  def setupDB(): Unit = {
    if (!hasDBInitialize)
      Player.initializeTable()

    def hasDBInitialize: Boolean = {
      DB getTable "Player" match {
        case Some(x) => true
        case None => false
      }
    }
  }
}
