package AstronautRunnerPackage.view

import AstronautRunnerPackage.MainApp
import AstronautRunnerPackage.MainApp.gameResult
import scalafx.scene.control.Label
import scalafxml.core.macros.sfxml

@sfxml
class GameOverController(val scoreLabel: Label, val coinScoreLabel: Label) {

  //Labels
  scoreLabel.text = gameResult.score.value.toString
  coinScoreLabel.text = gameResult.coinScore.value.toString

  //==================
  //Binded to Buttons
  //==================

  def backRestart(): Unit = {
    MainApp.clickSound()
    MainApp.startGame(MainApp.difficultyLevel)
  }

  def backMainMenu(): Unit = {
    MainApp.clickSound()
    MainApp.showMainMenu()
  }

}
