package AstronautRunnerPackage.view

import AstronautRunnerPackage.MainApp
import scalafx.scene.control.Button
import scalafxml.core.macros.sfxml

@sfxml
class MainMenuController(val MusicButton: Button) {

  //==================
  //Bind to Buttons
  //==================

  def chooseDifficulty(): Unit = {
    MainApp.clickSound()
    MainApp.showDifficultyLevel()
  }

  def chooseRules(): Unit = {
    MainApp.clickSound()
    MainApp.showRules()
  }

  def chooseLeaderboard(): Unit = {
    MainApp.clickSound()
    MainApp.showLeaderboard()
  }

  def chooseMusic(): Unit = {
    MainApp.clickSound()
    if (MainApp.toggleMusic()) {
      MusicButton.setText("Off Music")
    } else {
      MusicButton.setText("On Music")
    }
  }

}
