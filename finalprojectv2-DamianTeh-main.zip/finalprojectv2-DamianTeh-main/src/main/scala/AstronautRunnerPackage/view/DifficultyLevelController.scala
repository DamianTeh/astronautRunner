package AstronautRunnerPackage.view

import AstronautRunnerPackage.MainApp
import AstronautRunnerPackage.model.Difficulty.{Easy, Hard, Normal}
import scalafx.scene.control.TextField
import scalafxml.core.macros.sfxml

@sfxml
class DifficultyLevelController(val nameTextField: TextField) {

  // Bind nameTextField text to MainApp.playerName
  nameTextField.text = MainApp.playerName

  nameTextField.text.onChange((_, _, c) => {
    MainApp.playerName = c
  })

  //==================
  // Bind to buttons to select difficulties
  //==================

  def showHome(): Unit = {
    MainApp.clickSound()
    MainApp.showMainMenu()
  }

  def easyDifficulty(): Unit = {
    MainApp.clickSound()
    MainApp.startGame(Easy)
  }

  def normalDifficulty(): Unit = {
    MainApp.clickSound()
    MainApp.startGame(Normal)
  }

  def hardDifficulty(): Unit = {
    MainApp.clickSound()
    MainApp.startGame(Hard)
  }
}
