package AstronautRunnerPackage.view

import AstronautRunnerPackage.MainApp
import scalafxml.core.macros.sfxml

@sfxml
class RootLayoutController() {

  //==================
  //Bind to Buttons
  //==================

  def closeGame(): Unit = {
    System.exit(0);
  }

  def onMusic(): Unit = {
    if (!MainApp.toggleMusic()) {
    }
  }

  def offMusic(): Unit = {
    if (MainApp.toggleMusic()) {
    }
  }

}
