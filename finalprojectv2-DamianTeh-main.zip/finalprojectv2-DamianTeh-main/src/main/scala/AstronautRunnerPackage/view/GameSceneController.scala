package AstronautRunnerPackage.view

import AstronautRunnerPackage.MainApp
import AstronautRunnerPackage.MainApp.{difficultyLevel, gameResult, playerName}
import AstronautRunnerPackage.model.{Astronaut, Coin, Meteor, Player}
import AstronautRunnerPackage.model.Sound.{coinSound, gameOverSound, jetpackSound}
import scalafx.Includes._
import scalafx.animation.{AnimationTimer, KeyFrame, PauseTransition, Timeline}
import scalafx.scene.control.Label
import scalafx.scene.input.{KeyCode, KeyEvent}
import scalafx.scene.layout.AnchorPane
import scalafx.util.Duration
import scalafxml.core.macros.sfxml

import scala.util.Random

@sfxml
class GameSceneController(
                           private val gameArea: AnchorPane,
                           private var timer: Label,
                           private val countdownLabel: Label,
                           private var coinScoreLabel: Label
                         ) {

  // Variables that manage the state of the game
  private var startTime: Long = _
  private var score: Int = 0
  private var coinScore: Int = 0
  private var coins: List[Coin] = List()
  private var meteors: List[Meteor] = List()
  private var gameOver: Boolean = false

  // Initialize the astronaut
  private val astronaut = new Astronaut(0, 165)
  gameArea.children.addAll(astronaut.imageView, astronaut.hitbox)

  // Initialize the game loop
  private val gameLoop: AnimationTimer = AnimationTimer(_ => {
    if (!gameOver) {
      astronaut.applyGravity(gameArea.height.value)
      updateScore()
      generateCoins()
      moveAndCollectCoins()
      generateMeteors()
      moveAndCheckMeteors()
    } else if (gameOver) {
      countdownLabel.visible = true
      countdownLabel.text = "Game Over"
    }
  })

  // Set up the scene property change listener
  gameArea.sceneProperty().onChange { (_, _, newScene) =>
    if (newScene != null) {
      newScene.onKeyPressed = (event: KeyEvent) => movePlayer(event)
      Meteor.updateProperties()
      Coin.updateProperties
      startCountdown()
    }
  }

  // =====================
  // Player movement functions
  // =====================

  //Matching the keyboard and player input
  def movePlayer(event: KeyEvent): Unit = {
    if (!gameOver) {
      event.code match {
        case KeyCode.Up | KeyCode.W =>
          astronaut.moveVertically(-25, gameArea.height.value)
          jetpackSound.play()
        case KeyCode.Down | KeyCode.S =>
          astronaut.moveVertically(25, gameArea.height.value)
        case _ =>
      }
    }
  }

  // =====================
  // Game control functions
  // =====================

  //Starting game loop
  def startGameLoop(): Unit = {
    gameOver = false
    startTime = System.nanoTime()
    gameLoop.start()
  }

  //Stopping game loop
  def stopGameLoop(): Unit = {
    gameOver = true
    gameLoop.stop()
    gameOverSound.play()
    countdownLabel.visible = true
    countdownLabel.text = "Game Over"
    gameResult = new Player(playerName.toString(), score, coinScore, difficultyLevel.name.toString)
    gameResult.save()
    val pause = new PauseTransition(Duration(2000))
    pause.onFinished = _ => MainApp.showGameOver()
    pause.play()
  }

  //Initial game countdown
  def startCountdown(): Unit = {
    val countdownTimeline = new Timeline {
      keyFrames = List(
        KeyFrame(Duration(0), onFinished = _ => countdownLabel.text = "3"),
        KeyFrame(Duration(1000), onFinished = _ => countdownLabel.text = "2"),
        KeyFrame(Duration(2000), onFinished = _ => countdownLabel.text = "1"),
        KeyFrame(Duration(3000), onFinished = _ => {
          countdownLabel.text = "Go!"
          startGameLoop()
        }),
        KeyFrame(Duration(4000), onFinished = _ => countdownLabel.visible = false)
      )
    }
    countdownTimeline.play()
  }

  //Updates score
  def updateScore(): Unit = {
    score = ((System.nanoTime() - startTime) / 1e6).toInt
    timer.text = f"Score: $score%05d"
  }

  // =====================
  // Coin related functions
  // =====================

  //Generating coin based on probability
  def generateCoins(): Unit = {
    if (Random.nextDouble() < 0.005) {
      val newCoin = new Coin(gameArea.width.value * 0.9 , Random.nextDouble() * gameArea.height.value * 0.9)
      gameArea.children.addAll(newCoin.imageView, newCoin.hitbox)
      coins = newCoin :: coins
    }
  }

  //Moving coin from right to left, remove it when offscreen and checking for collisions
  def moveAndCollectCoins(): Unit = {
    coins = coins.filter { coin =>
      coin.move()
      if (coin.isOffScreen) {
        gameArea.children.removeAll(coin.imageView, coin.hitbox)
        false
      } else {
        if (coin.checkCollision(astronaut)) {
          gameArea.children.removeAll(coin.imageView, coin.hitbox)
          coinSound.play()
          coinScore += 1
          coinScoreLabel.text = f":$coinScore"
          false
        } else {
          true
        }
      }
    }
  }

  // =====================
  // Meteor related functions
  // =====================

  //Generating meteor based on probability and lesser than Maximum number (based on difficulty)
  def generateMeteors(): Unit = {
    if (meteors.length < Meteor.maxNumber && Random.nextDouble() < Meteor.spawnRate) {
      val newMeteor = new Meteor(gameArea.width.value * 0.9 , Random.nextDouble() * gameArea.height.value * 0.9 )
      gameArea.children.addAll(newMeteor.imageView, newMeteor.hitbox)
      meteors = newMeteor :: meteors
    }
  }

  //Moving meteor from right to left, remove it when offscreen and check for collision
  def moveAndCheckMeteors(): Unit = {
    meteors = meteors.filter { meteor =>
      meteor.move()
      if (meteor.isOffScreen) {
        gameArea.children.removeAll(meteor.imageView, meteor.hitbox)
        false
      } else {
        if (meteor.checkCollision(astronaut)) {
          gameOver = true
          stopGameLoop()
        }
        true
      }
    }
  }
}