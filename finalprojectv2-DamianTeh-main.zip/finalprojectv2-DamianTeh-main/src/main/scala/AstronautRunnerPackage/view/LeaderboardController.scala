package AstronautRunnerPackage.view

import AstronautRunnerPackage.MainApp
import AstronautRunnerPackage.model.Player
import AstronautRunnerPackage.util.CommonUtil
import scalafx.beans.property.StringProperty
import scalafx.scene.control.{TableColumn, TableView}
import scalafxml.core.macros.sfxml

@sfxml
class LeaderboardController(
                             val leaderboardTable: TableView[Player],
                             val nameTableColumn: TableColumn[Player, String],
                             val scoreTableColumn: TableColumn[Player, String],
                             val coinScoreTableColumn: TableColumn[Player, String]
                           ) {

  //Loading the leaderboard calling the Player class
  def loadLeaderboard(difficulty: String): Unit = {
    val players: List[Player] = Player.getPlayersByDifficulty(difficulty, 15)
    leaderboardTable.items = CommonUtil.listToObservableBuffer(players)
  }

  //==================
  //Retrieving table info
  //==================

  nameTableColumn.cellValueFactory = (x) => {
    new StringProperty(x.value.name.value)
  }

  scoreTableColumn.cellValueFactory = (x) => {
    new StringProperty(x.value.score.value.toString)
  }

  coinScoreTableColumn.cellValueFactory = (x) => {
    new StringProperty(x.value.coinScore.value.toString)
  }

  //==================
  //Bind to Buttons
  //==================

  //Filter by easy difficulty
  def showEasy(): Unit = {
    MainApp.clickSound()
    loadLeaderboard("Easy")
  }

  //Filter by normal difficulty
  def showNormal(): Unit = {
    MainApp.clickSound()
    loadLeaderboard("Normal")
  }

  //Filter by hard difficulty
  def showHard(): Unit = {
    MainApp.clickSound()
    loadLeaderboard("Hard")
  }

  //Close leaderboard page and go back to mainmenu
  def closeLeaderboard(): Unit = {
    MainApp.clickSound()
    MainApp.showMainMenu()
  }

  loadLeaderboard("Normal")
}

