package AstronautRunnerPackage.view
import AstronautRunnerPackage.MainApp
import scalafxml.core.macros.sfxml

@sfxml
class RulesController() {

  //==================
  //Bind to Buttons
  //==================

  def closeRules(): Unit = {
    MainApp.clickSound()
    MainApp.showMainMenu()
  }

}